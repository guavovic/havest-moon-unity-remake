### Harvest Moon Text Interpreter
### 0.1 - 2023
# Requires pypng

# This program decodes the ingame 4bpp sprites, read as db info into graphics

import sys, getopt, png