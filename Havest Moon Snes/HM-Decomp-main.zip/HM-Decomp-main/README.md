# Harvest Moon SNES Disassembly

Supported ROMS:

* Harvest Moon (USA) `md5: c9bf36a816b6d54aed79d43a6c45111a`

## Why

So, for reasons beyond even my comprehension, I decided to decompile and dissasemble this game. This was my first HM game, and it holds a huge place in my heart, even if... it kinda sucks.

## Status
The code part of the rom as been fully decompiled, a good ammount of code has been underestood and commented, but theres a lot of work still to do. Theres aton of flags still in the air tho.
* Bank 80: Around 30% done. Needs a second pass
* Bank 81: Least underestood bank. 1-3%
* Bank 82:
* Bank 83:
* Bank 84:
* Bank 85:

## How
Im used [DiztinGUIsh](https://github.com/IsoFrieze/DiztinGUIsh) to decompile the code. Im gonna add the other regions once this is more advanced. You can compile the code using [asar](https://github.com/RPGHacker/asar) with main.asm as input.

### Audio
I find audio things hard, so I decided im not gonna dissasemble audio functions.