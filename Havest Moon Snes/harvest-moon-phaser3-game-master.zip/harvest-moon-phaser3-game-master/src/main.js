import Phaser from 'phaser'
import config from './config';

export default new Phaser.Game( config )
