<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.5" name="sprites-sheet" tilewidth="80" tileheight="80" tilecount="40" columns="8">
 <image source="../images/sprites-sheet.png" width="640" height="400"/>
</tileset>
